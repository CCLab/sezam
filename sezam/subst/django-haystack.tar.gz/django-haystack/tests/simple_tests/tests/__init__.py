import warnings
warnings.simplefilter('ignore', Warning)

from simple_tests.tests.simple_query import *
from simple_tests.tests.simple_backend import *
