import warnings
warnings.simplefilter('ignore', Warning)

from elasticsearch_tests.tests.inputs import *
from elasticsearch_tests.tests.elasticsearch_query import *
from elasticsearch_tests.tests.elasticsearch_backend import *
